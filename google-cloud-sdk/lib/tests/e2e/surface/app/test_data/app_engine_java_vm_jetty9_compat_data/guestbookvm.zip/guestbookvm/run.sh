#!/bin/sh
/Library/Java/JavaVirtualMachines/jdk1.8.0_40.jdk/Contents/Home/jre/bin/java \
-Dorg.eclipse.jetty.LEVEL=INFO \
-Dgcloud.java.application=/Users/ludo/githubrepos/serbia/demos/target/ademo-slovenia-1.0-SNAPSHOT \
-Djetty.home=/Users/ludo/google-cloud-sdk/platform/google_appengine/google/appengine/tools/java/lib/java-managed-vm/appengine-java-vmruntime \
-Djetty.base=/Users/ludo/google-cloud-sdk/platform/google_appengine/google/appengine/tools/java/lib/jetty-base-sdk \
-jar /Users/ludo/google-cloud-sdk/platform/google_appengine/google/appengine/tools/java/lib/java-managed-vm/appengine-java-vmruntime/start.jar